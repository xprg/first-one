import java.util.Random;
public class Main {
    static class ThreadRunner extends Thread {
        String contestantName;
        int chancesOfResting;
        int contestantSpeed;
        int stepsCompleted = 0;
        boolean raceFinished = false;
        Random random;
        ThreadRunner(String name, int lik, int speed) {
            this.contestantName = name;
            this.chancesOfResting = lik;
            this.contestantSpeed = speed;
            random = new Random();
        }
        public void run() {
            if(!raceFinished) {
                for (int i = 0; i < 1000; ) {
                    try {
                        System.out.println(contestantName + " : " + i);
                        i += step();
                        stepsCompleted = i;
                        if(stepsCompleted == 1000){
                            tortoise.raceFinished = true;
                            hare.raceFinished = true;
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    finished();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        synchronized int step() throws InterruptedException {
            Thread.sleep(100);
            if (chancesOfResting < (random.nextInt(100) + 1))
                return contestantSpeed;
            else
                return 0;
        }
        synchronized void finishSecond() throws InterruptedException {
            Thread.sleep(100);
            for (int i = stepsCompleted; i < 1000; ) {
                try {
                    System.out.println(contestantName + " : " + i);
                    i += step();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(contestantName + " : 1000");
            if(contestantName.equals("Hare")){
                System.out.println("The race is over! The Tortoise is the winner.\n");
                System.out.println("Hare : You beat me fare and square.");
                hare.stop();
            }
            else{
                System.out.println("The race is over! The Hare is the winner.\n");
                System.out.println("Tortoise : You beat me fare and square.");
                tortoise.stop();
            }
        }
        synchronized void finished() throws InterruptedException {
            System.out.println(contestantName + " : 1000");
            if (contestantName.equals("Tortoise")) {
                System.out.println(contestantName + " : I finished!\n");
                hare.finishSecond();
            }
            else {
                System.out.println(contestantName + " : I finished!\n");
                tortoise.finishSecond();
            }
        }
    }
    static ThreadRunner tortoise, hare;
    public static void main(String[] args) {
        tortoise = new ThreadRunner("Tortoise", 0, 10);
        hare = new ThreadRunner("Hare", 90, 100);
        System.out.println("start!");
        hare.start();
        tortoise.start();
    }
}