
import java.applet.*;
import java.awt.*;

public class shapesdisp extends Applet
{
public void paint(Graphics g)
  {
    g.setColor(Color.red);
    g.drawRect(70,100,30,30);
    g.fillRect(170,100,30,30);

    g.setColor(Color.blue);
    g.drawOval(70,200,30,30);
    g.fillOval(170,200,30,30);
    
    g.setColor(Color.pink);
    g.drawArc(90,150,30,30,30,270);  
    g.fillArc(270,150,30,30,0,180);  
  }
}
/*
<applet code="shapesdisp.class" width="300" height="300">
</applet>
*/
