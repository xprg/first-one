public class hotncold {

    public static void main(String[] args) {

        HamBurger b1 = new HamBurger();
        b1.addition("Cheese", 1);
        b1.addition("Lettuce", 1);
        b1.addition("lasna", 3);

        
       
        HealthyBurger h1 = new HealthyBurger("Turkey", 8.50);
        h1.addition("Egg", 1);
        h1.addition("Lentil", 3);
        h1.addition("Cheese", 1);
        h1.addition("Lettuce", 2);
        h1.addition("lasna", 3);
       

        DeluxeBurger d1 = new DeluxeBurger("White bread", "Turkey", 14.50);
        d1.addition("Lettuce", 2);
        b1.display();
        h1.display();
        d1.display();

    }
}
 class HamBurger {

    private String breadType;
    private String meatType;
    private double basePrice;
    private double finalPrice;
    private int count;

    private String[] additions;
    private double[] additionsPrice;

    public HamBurger() {
        this("Regular Burger","White Meat",9.99);        
    }

    public HamBurger(String breadType,String Meat, double basePrice) 
    {
        this.breadType = breadType;
        this.meatType = Meat;
        this.basePrice = basePrice;
        this.count=-1;
        this.additions = new String[4];
        this.additionsPrice=new double[4];
    }

    public String getBreadType() {
        return breadType;
    }

    public String getMeatType() {
        return meatType;
    }


    public double getBasePrice() {
        return basePrice;
    }

    void addition(String extraTopping, double price) 
    {
        
        if(count<3)
        {
        ++count;
        additions[count] = extraTopping;
        additionsPrice[count] = price;
        System.out.println("Added " +  additions[count] + " for an extra $" + additionsPrice[count]);
        }
        else
        System.out.println("Sorry 4 Additions Already On List");
    }


    public double itemizeBurger() {

        System.out.println("\n\n\t\tBurger " + " on a " + this.breadType + " with " +
                this.meatType + " for $" + basePrice+"\n");
        finalPrice=basePrice;
        for(int i=0;i<=count;++i)
        {
        finalPrice+=additionsPrice[i];
        System.out.println("With " +  additions[i] + " for an extra $" + additionsPrice[i]);
        }
        
        return finalPrice;
    }
    public void display()
    {
        
        System.out.println("\n---------------------------------------------------\n");
        System.out.println("\t\tHAM BURGER\n");

        System.out.println("\tGrand Total FOR HAMBURGER: " +  "  $" + itemizeBurger()+"\n\n");
        
        System.out.println("\n---------------------------------------------------\n");
    }
}
 class HealthyBurger extends HamBurger {

    private String[] healthyExtra;
    private double[] healthyExtraPrice;
    private int count;

    public HealthyBurger(String meatType, double basePrice) {
        super("Brown Bread Roll", meatType, basePrice);
        this.count=-1;
        healthyExtra=new String[2];
        healthyExtraPrice=new double[2];
    }
    void addition(String extraTopping, double price) 
    {
        
        if(count<3)
        {
        ++count;
        super.addition(extraTopping, price);
        }
        else if(count<5)
        {
            ++count;
            healthyExtra[count-4] = extraTopping;
            healthyExtraPrice[count-4] = price;
            System.out.println("Added " +  healthyExtra[count-4] + " for an extra $" + healthyExtraPrice[count-4]);
        }
        else
        System.out.println("Sorry 6 Additions Already On List");
    }
 

    @Override
    public double itemizeBurger() {
        double healthyBurgerPrice = super.itemizeBurger();
        
       if(count>=4)
       {
            for(int i=0;i<=count-4;++i)
            {
            healthyBurgerPrice+=healthyExtraPrice[i];
            System.out.println("With " +  healthyExtra[i] + " for an extra $" + healthyExtraPrice[i]);
            }
       }
        return healthyBurgerPrice;
    }
    public void display()
    {
        
        System.out.println("\n---------------------------------------------------\n");
        
        System.out.println("\t\tHELATHY BURGER\n");

        System.out.println("\tGrand Total FOR HELATHY_BURGER: " +  "  $" + itemizeBurger()+"\n\n");
        
        System.out.println("\n---------------------------------------------------\n");
    }
}
 class DeluxeBurger extends HamBurger {
    public DeluxeBurger(String rollType, String meatType, double basePrice) {
        super(rollType, meatType, basePrice);
        super.addition("Drink",1.5);
        super.addition("Chips",1.0);
    }

    @Override
    void addition(String extraTopping, double price) {
       System.out.println("Cannot add additional items to Deluxe burger");
    }
    public void display()
    {
        System.out.println("\n---------------------------------------------------\n");
        System.out.println("\t\tDELUX BURGER");
        System.out.println("\n\tGrand Total FOR DELUX_BURGER: " +  "  $" + itemizeBurger()+"\n\n");
        
        System.out.println("\n---------------------------------------------------\n");
    }
}