
import java.applet.*;
import java.awt.*;

public class dispmsg extends Applet
{
	public void paint(Graphics g)
	{		
		g.drawString ("This message is displayed using applet", 25, 50);
	  
	}
}
/*
 <applet code="dispmsg" width=200 height=60>
</applet>
*/